const SignIn = () => {
    return (
        <div className="container mt-3">
            <h1 className="text-center bg-success text-dark bg-opacity-50">SignIn</h1>
            <form>
                <div className="mb-3 mt-3">
                    <label htmlFor="email">Email:</label>
                    <input type="email" className="form-control" id="email" placeholder="Enter email" name="email" required />
                </div>
                <div className="mb-3">
                    <label htmlFor="pwd">Password:</label>
                    <input type="password" className="form-control" id="pwd" placeholder="Enter password" name="pswd" required />
                </div>
                <div className="d-flex">
                    <div className="p-2 flex-fill d-grid">
                        <button type="submit" className="btn btn-warning">SignIn</button>
                    </div>
                    <div className="p-2 flex-fill d-grid">
                        <a href="/html/signUp.html" className="btn btn-primary">SignUp</a>
                    </div>
                    <div className="p-2 flex-fill d-grid">
                        <a href="/html/main.html" className="btn btn-danger">Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    )
}

export default SignIn;