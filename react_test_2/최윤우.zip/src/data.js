export const list = [
    { name: "스티븐", email: "jobs@shellfolder.com", pwd: "111", job: "개발자", gender: 1 },
    { name: "에브릴", email: "lavigne@shellfolder.com", pwd: "222", job: "가수", gender: 2 }
]